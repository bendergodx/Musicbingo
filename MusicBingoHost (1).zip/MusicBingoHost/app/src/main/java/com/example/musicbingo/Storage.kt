package com.example.musicbingo

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Song(
    val id: String,
    val uri: String,
    val title: String,
    val artist: String,
)

/** Хранит список песен и настройки в SharedPreferences (без интернета и баз данных). */
class SongStore(context: Context) {
    private val prefs = context.getSharedPreferences("bingo", Context.MODE_PRIVATE)

    fun loadSongs(): List<Song> {
        val raw = prefs.getString("songs", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Song(
                    id = o.getString("id"),
                    uri = o.getString("uri"),
                    title = o.optString("title"),
                    artist = o.optString("artist"),
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveSongs(songs: List<Song>) {
        val arr = JSONArray()
        songs.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("uri", it.uri)
                    .put("title", it.title)
                    .put("artist", it.artist)
            )
        }
        prefs.edit().putString("songs", arr.toString()).apply()
    }

    var clipSeconds: Int
        get() = prefs.getInt("clip", 30)
        set(v) = prefs.edit().putInt("clip", v).apply()

    var randomStart: Boolean
        get() = prefs.getBoolean("randomStart", true)
        set(v) = prefs.edit().putBoolean("randomStart", v).apply()
}
