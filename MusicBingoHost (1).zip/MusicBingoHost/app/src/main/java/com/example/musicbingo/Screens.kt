@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.musicbingo

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

private fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

// =====================================================================
// Экран подготовки: список песен и настройки
// =====================================================================
@Composable
fun PlaylistScreen(vm: GameViewModel) {
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris -> vm.addSongs(uris) }

    var editing by remember { mutableStateOf<Song?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Музыкальное бинго") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                Icon(Icons.Default.Add, contentDescription = "Добавить песни")
            }
        },
        bottomBar = {
            Button(
                onClick = { vm.startGame() },
                enabled = vm.songs.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text("Начать игру (${vm.songs.size})")
            }
        }
    ) { padding ->
        LazyColumn(Modifier.padding(padding)) {
            item {
                Card(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Длина фрагмента", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(15, 30, 45, 60, 0).forEach { sec ->
                                FilterChip(
                                    selected = vm.clipSeconds == sec,
                                    onClick = { vm.setClip(sec) },
                                    label = { Text(if (sec == 0) "Целиком" else "$sec с") }
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Случайное место в песне")
                                Text(
                                    "Играть не с начала, а с произвольного момента",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Switch(
                                checked = vm.randomStart && vm.clipSeconds > 0,
                                onCheckedChange = { vm.setRandomStart(it) },
                                enabled = vm.clipSeconds > 0
                            )
                        }
                    }
                }
            }
            item {
                Text(
                    text = if (vm.songs.isEmpty())
                        "Добавьте аудиофайлы кнопкой «+». Для карточки 5×5 желательно от 40 песен."
                    else
                        "Песен в списке: ${vm.songs.size}",
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
            items(vm.songs, key = { it.id }) { song ->
                ListItem(
                    headlineContent = { Text(song.title) },
                    supportingContent = { if (song.artist.isNotBlank()) Text(song.artist) },
                    trailingContent = {
                        Row {
                            IconButton(onClick = { editing = song }) {
                                Icon(Icons.Default.Edit, contentDescription = "Изменить")
                            }
                            IconButton(onClick = { vm.removeSong(song.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Удалить")
                            }
                        }
                    }
                )
                HorizontalDivider()
            }
            item { Spacer(Modifier.height(72.dp)) } // место под кнопку «+»
        }
    }

    editing?.let { song ->
        var title by remember(song.id) { mutableStateOf(song.title) }
        var artist by remember(song.id) { mutableStateOf(song.artist) }
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Название и исполнитель") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(title, { title = it }, label = { Text("Название") }, singleLine = true)
                    OutlinedTextField(artist, { artist = it }, label = { Text("Исполнитель") }, singleLine = true)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.updateSong(song.id, title, artist)
                    editing = null
                }) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Отмена") } }
        )
    }
}

// =====================================================================
// Экран игры
// =====================================================================
@Composable
fun GameScreen(vm: GameViewModel) {
    var confirmExit by remember { mutableStateOf(false) }
    BackHandler { confirmExit = true }

    // Не гасим экран во время игры
    val view = LocalView.current
    DisposableEffect(view) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Сыграно ${vm.played.size} · осталось ${vm.remaining}") },
                actions = { TextButton(onClick = { confirmExit = true }) { Text("Завершить") } }
            )
        }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Card(Modifier.fillMaxWidth()) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val cur = vm.current
                    if (cur == null) {
                        Text(
                            if (vm.played.isEmpty()) "Нажмите «Следующая песня»" else "Песни закончились",
                            style = MaterialTheme.typography.headlineSmall,
                            textAlign = TextAlign.Center
                        )
                    } else {
                        Text("Песня №${vm.played.size}", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(8.dp))
                        if (vm.revealed) {
                            Text(
                                cur.title,
                                style = MaterialTheme.typography.headlineMedium,
                                textAlign = TextAlign.Center
                            )
                            if (cur.artist.isNotBlank()) {
                                Text(
                                    cur.artist,
                                    style = MaterialTheme.typography.titleMedium,
                                    textAlign = TextAlign.Center
                                )
                            }
                        } else {
                            Text("???", style = MaterialTheme.typography.headlineLarge)
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = { vm.reveal() }) { Text("Показать ответ") }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            val fraction = if (vm.totalMs > 0) (vm.elapsedMs.toFloat() / vm.totalMs).coerceIn(0f, 1f) else 0f
            LinearProgressIndicator(progress = { fraction }, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(vm.elapsedMs), style = MaterialTheme.typography.bodySmall)
                Text(formatTime(vm.totalMs), style = MaterialTheme.typography.bodySmall)
            }

            vm.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
            }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { vm.replay() },
                    enabled = vm.current != null,
                    modifier = Modifier.weight(1f)
                ) { Text("Заново") }
                Button(
                    onClick = { vm.togglePlay() },
                    enabled = vm.current != null,
                    modifier = Modifier.weight(1f)
                ) { Text(if (vm.isPlaying) "Пауза" else "Играть") }
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { vm.next() },
                enabled = vm.remaining > 0,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) { Text("Следующая песня") }

            Spacer(Modifier.height(16.dp))
            Text("Уже прозвучали", style = MaterialTheme.typography.titleMedium)
            HorizontalDivider(Modifier.padding(vertical = 4.dp))
            LazyColumn(Modifier.weight(1f)) {
                val list = vm.played.asReversed()
                items(list.size) { i ->
                    val s = list[i]
                    val n = vm.played.size - i
                    Text(
                        text = "$n. ${s.title}" + if (s.artist.isNotBlank()) " — ${s.artist}" else "",
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }
            }
        }
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("Завершить игру?") },
            text = { Text("История сыгранных песен будет сброшена.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmExit = false
                    vm.endGame()
                }) { Text("Завершить") }
            },
            dismissButton = { TextButton(onClick = { confirmExit = false }) { Text("Продолжить игру") } }
        )
    }
}
