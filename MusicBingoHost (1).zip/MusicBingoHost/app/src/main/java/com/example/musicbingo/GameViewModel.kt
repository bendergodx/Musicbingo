package com.example.musicbingo

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.media.MediaMetadataRetriever
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.random.Random

class GameViewModel(app: Application) : AndroidViewModel(app) {

    private val store = SongStore(app)

    // ---------- Плейлист и настройки ----------
    val songs = mutableStateListOf<Song>().apply { addAll(store.loadSongs()) }

    var clipSeconds by mutableIntStateOf(store.clipSeconds)
        private set
    var randomStart by mutableStateOf(store.randomStart)
        private set

    fun setClip(seconds: Int) {
        clipSeconds = seconds
        store.clipSeconds = seconds
    }

    fun setRandomStart(value: Boolean) {
        randomStart = value
        store.randomStart = value
    }

    fun addSongs(uris: List<Uri>) {
        val ctx = getApplication<Application>()
        val known = songs.map { it.uri }.toSet()
        viewModelScope.launch {
            val added = withContext(Dispatchers.IO) {
                uris.filter { it.toString() !in known }.map { uri ->
                    try {
                        ctx.contentResolver.takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    } catch (_: Exception) {
                    }
                    readSong(uri)
                }
            }
            songs.addAll(added)
            store.saveSongs(songs)
        }
    }

    fun updateSong(id: String, title: String, artist: String) {
        val i = songs.indexOfFirst { it.id == id }
        if (i >= 0) {
            songs[i] = songs[i].copy(title = title.trim(), artist = artist.trim())
            store.saveSongs(songs)
        }
    }

    fun removeSong(id: String) {
        songs.removeAll { it.id == id }
        store.saveSongs(songs)
    }

    private fun readSong(uri: Uri): Song {
        val ctx = getApplication<Application>()
        var title: String? = null
        var artist: String? = null
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(ctx, uri)
            title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
            artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
        } catch (_: Exception) {
        } finally {
            try { mmr.release() } catch (_: Exception) {}
        }
        if (title.isNullOrBlank()) {
            title = try {
                ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (c.moveToFirst() && idx >= 0) c.getString(idx)?.substringBeforeLast('.') else null
                }
            } catch (_: Exception) {
                null
            }
        }
        return Song(
            id = UUID.randomUUID().toString(),
            uri = uri.toString(),
            title = title?.takeIf { it.isNotBlank() } ?: "Без названия",
            artist = artist.orEmpty(),
        )
    }

    // ---------- Игра ----------
    var gameActive by mutableStateOf(false)
        private set
    val played = mutableStateListOf<Song>()
    var current by mutableStateOf<Song?>(null)
        private set
    var remaining by mutableIntStateOf(0)
        private set
    var revealed by mutableStateOf(false)
        private set
    var isPlaying by mutableStateOf(false)
        private set
    var elapsedMs by mutableLongStateOf(0L)
        private set
    var totalMs by mutableLongStateOf(0L)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    private var queue = ArrayDeque<Song>()
    private var pendingStart = false
    private var clipStartMs = 0L

    private val player: ExoPlayer = ExoPlayer.Builder(app).build().apply {
        setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            true
        )
        addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && pendingStart) {
                    pendingStart = false
                    applyStart()
                }
            }

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onPlayerError(e: PlaybackException) {
                pendingStart = false
                error = "Не удалось воспроизвести файл. Нажмите «Следующая песня»."
            }
        })
    }

    init {
        // Тикер: обновляет прогресс и останавливает музыку по окончании фрагмента.
        viewModelScope.launch {
            while (true) {
                delay(200)
                if (current == null) continue
                val pos = player.currentPosition
                val dur = player.duration.takeIf { it != C.TIME_UNSET } ?: 0L
                elapsedMs = (pos - clipStartMs).coerceAtLeast(0L)
                val clipMs = clipSeconds * 1000L
                totalMs = if (clipMs > 0) minOf(clipMs, (dur - clipStartMs).coerceAtLeast(0L)) else dur
                if (isPlaying && clipMs > 0 && elapsedMs >= clipMs) {
                    player.pause()
                }
            }
        }
    }

    private fun applyStart() {
        val clipMs = clipSeconds * 1000L
        val dur = player.duration.takeIf { it != C.TIME_UNSET } ?: 0L
        clipStartMs = 0L
        if (randomStart && clipMs > 0) {
            // Не начинаем с самых последних секунд, чтобы фрагмент не оборвался.
            val maxStart = dur - clipMs - 1000L
            if (maxStart > 0) {
                clipStartMs = Random.nextLong(maxStart)
                player.seekTo(clipStartMs)
            }
        }
        player.play()
    }

    fun startGame() {
        if (songs.isEmpty()) return
        queue = ArrayDeque(songs.shuffled())
        played.clear()
        current = null
        revealed = false
        error = null
        remaining = queue.size
        gameActive = true
    }

    fun endGame() {
        player.stop()
        player.clearMediaItems()
        pendingStart = false
        current = null
        gameActive = false
    }

    fun next() {
        val song = queue.removeFirstOrNull() ?: return
        remaining = queue.size
        current = song
        played.add(song)
        revealed = false
        error = null
        elapsedMs = 0L
        totalMs = 0L
        clipStartMs = 0L
        pendingStart = true
        player.playWhenReady = false
        player.setMediaItem(MediaItem.fromUri(Uri.parse(song.uri)))
        player.prepare()
    }

    fun reveal() {
        revealed = true
    }

    fun replay() {
        if (current == null) return
        player.seekTo(clipStartMs)
        player.play()
    }

    fun togglePlay() {
        if (current == null) return
        val clipMs = clipSeconds * 1000L
        when {
            isPlaying -> player.pause()
            player.playbackState == Player.STATE_ENDED -> replay()
            clipMs > 0 && elapsedMs >= clipMs -> replay()
            else -> player.play()
        }
    }

    override fun onCleared() {
        player.release()
    }
}
